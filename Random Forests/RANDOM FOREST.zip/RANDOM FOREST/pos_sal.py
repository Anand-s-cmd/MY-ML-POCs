import pandas as pd
import numpy as np 
import matplotlyb.pyplot as plt

df=pd.read_csv(r'C:\\EXCELR\\NOTES WRITTEN\\RANDOM FOREST\\POSIION_SALARIES.csv')
x=df.iloc[:,0:1].values
y=df.iloc[:,-1].values
x
y


from sklearn.ensemble import RandomForestRegressor
regressor=RandomForestRegressor(n_estimators=10, random_state=0)
reg_mod=regressor.fit(x,y)
y_pred=reg_mod.predict(6.5)#array([167000.])

#visualizing the rF for higher 
