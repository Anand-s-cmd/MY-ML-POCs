import pandas as pd
import matplotlib.pyplot as plt
data = pd.read_csv("C:/EXCELR/NOTES WRITTEN/DECISION TREE/iris.csv")
data.head()
data['Species'].unique()
data.Species.value_counts()

cols=list(data.columns)
cols
predictors=cols[:4]
target=cols[-1]

from sklearn.model_selection import train_test_split
train,test=train_test_split(data,test_size=0.3)
from sklearn.tree import DecisionTreeClassifier
model=DecisionTreeClassifier(criterion = 'entropy')
model.fit(train[predictors],train[target])

pred=model.predict(test[predictors])


