""" DT ASSIGNMENT FOR COMPANY DATA SET"""

import pandas as pd
import matplotlib.pyplot as plt
data = pd.read_csv("C:\\EXCELR\\NOTES WRITTEN\\DECISION TREE\\DATA SET\\Company_Data.csv")
data.head()
colnames=list(data.columns)
predictors=colnames[1:10]
predictors
target=colnames[0]

# Splitting data into training and testing data set

import numpy as np

from sklearn.model_selection import train_test_split
train,test = train_test_split(data,test_size = 0.3)

from sklearn.tree import DecisionTreeClassifier
help(DecisionTreeClassifier)

model=DecisionTreeClassifier(criterion='entropy')
""" NOW DECISION CLASSIFIER OBJECT IS CREATED NOW FIT THE DATA BELOW"""
model.fit(train[predictors],train[target]) 
"""
