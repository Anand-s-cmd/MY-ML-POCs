import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt
import statsmodels.formula.api as smf

# reading a csv file using pandas library
cal=pd.read_csv("C:\\EXCELR\\Assignments\\Simple Linear Regression\\calories_consumed.csv")
cal.columns
cal=cal.rename(columns={"Weight gained (grams)": "weight", "Calories Consumed": "calories"})
cal.shape

from sklearn.model_selection import train_test_split
train,test=train_test_split(cal,test_size=0.2)

train.columns
test.columns
plt.hist(train.weight)
plt.hist(train.calories)
plt.boxplot(train.weight,0,"rs",0)#OUTLIERS FOUND
plt.boxplot(train.calories,0,"rs",0)


plt.scatter(train.weight,train.calories,color="red");plt.xlabel("weight");plt.ylabel("calories")

train.weight.corr(train.calories)#0.0.8994853021642999

train_model=smf.ols("train.weight~train.calories",data=train).fit()


train_model.summary()
"""
R-squared:                       0.809
 MEANS IF I VARY 1% IN WEIGHTS  I CAN PREDICT VARIATION 80% IN CALORIES
Adj. R-squared:                  0.782

                     coef    std err          t      P>|t|      [0.025      0.975]
==============================================================================
Intercept       -482.5069    140.528     -3.434      0.011    -814.802    -150.211
train.calories     0.3562      0.065      5.446      0.001       0.202       0.511
==============================================================================
"""

train_pred=train_model.predict(train)
train_residual_errors=train.weight-train_pred

#lets find the accuracy for predicted and actual output
train_pred.corr(train.calories)#0.9999999999999998 ---> good

plt.scatter(train.calories,train.weight,color="red")
plt.plot(train.calories,train_pred);plt.xlabel("calories");plt.ylabel("weight")

""" I WANT TO SEE THE SCATTER DIAGRAM FOR RESIDUAL ERROR TO CHECK THE HOMOSCADASTICITY"""

import statsmodels.api as sm
fig = sm.qqplot(train_residual_errors)
 #plt.show()

# Now lets see for test data
test.shape
train.shape
test_pred=train_model.predict(test)

print("full data")
cal
print("train data")
train.head()
print("test data")
test.head()


