""" I WANT TO SEE THE SCATTER DIAGRAM FOR RESIDUAL ERROR TO CHECK THE HOMOSCADASTICITY"""
import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt
import statsmodels.formula.api as smf

# reading a csv file using pandas library
wcat=pd.read_csv("C:\\EXCELR\\NOTES WRITTEN\Regression\\wc-at.csv")
wcat.columns
wcat.shape

plt.hist(wcat.Waist)
plt.hist(wcat.AT)

plt.boxplot(wcat.Waist,0,"rs",0)
plt.boxplot(wcat.AT,0,"rs",0)

import matplotlib.pyplot as plt
plt.scatter(wcat.Waist,wcat.AT);plt.xlabel("Waist");plt.xlabel("AT")

wcat.Waist.corr(wcat.AT)#0.8185578128958533

mod1=smf.ols("AT~Waist",data=wcat).fit()
mod1.summary()
"""
 R-squared:                       0.670
 Adj. R-squared:                  0.667

==============================================================================
                 coef    std err          t      P>|t|      [0.025      0.975]
------------------------------------------------------------------------------
Intercept   -215.9815     21.796     -9.909      0.000    -259.190    -172.773
Waist          3.4589      0.235     14.740      0.000       2.994       3.924
==============================================================================
"""
mod1_pred=mod1.predict(wcat)
residual_errors=wcat.AT-mod1_pred

#lets find the final corelation between the predicted values and actual output values

mod1_pred.corr(wcat.AT)# 0.8185578128958535
plt.scatter(wcat.Waist,wcat.AT,color="red")
plt.plot(wcat.Waist,mod1_pred);plt.xlabel("Waist");plt.ylabel("AT")

#still  0.8185578128958535 lets go to tranformation technique


#LOG TRANSFORMATION
plt.scatter(np.log(wcat.Waist),wcat.AT);plt.xlabel("Waist");plt.xlabel("AT")

np.log(wcat.Waist).corr(wcat.AT)#0.8217781862645356

mod2=smf.ols("AT~np.log(Waist)",data=wcat).fit()
mod2.summary()
"""
R-squared:                       0.675--> slight variation in the R2 lets see
 Adj. R-squared:                  0.672
 =================================================================================
                    coef    std err          t      P>|t|      [0.025      0.975]
---------------------------------------------------------------------------------
Intercept     -1328.3420     95.923    -13.848      0.000   -1518.498   -1138.186
np.log(Waist)   317.1356     21.258     14.918      0.000     274.994     359.277
==============================================================================
"""
mod2_pred=mod2.predict(wcat)
residual_errors2=wcat.AT-mod2_pred

# again build and the correlation between actual output and predicted variable and see

mod2_pred.corr(wcat.AT)#0.8217781862645354
plt.scatter(wcat.Waist,wcat.AT,color="red")
plt.plot(wcat.Waist,mod2_pred);plt.xlabel("Waist");plt.ylabel("AT")

#LETS GO TO EXP TRANFORMATION

plt.scatter(wcat.Waist,np.log(wcat.AT));plt.xlabel("Waist");plt.xlabel("AT")

wcat.Waist.corr(np.log(wcat.AT))# 0.8409006876081181

mod3=smf.ols("np.log(AT)~Waist",data=wcat).fit()
mod3.summary()
"""
R-squared:                       0.707
Adj. R-squared:                  0.704
==============================================================================
                 coef    std err          t      P>|t|      [0.025      0.975]
------------------------------------------------------------------------------
Intercept      0.7410      0.233      3.185      0.002       0.280       1.202
Waist          0.0403      0.003     16.073      0.000       0.035       0.045
==============================================================================
"""
mod3_pred=mod3.predict(wcat)
residual_error3=wcat.AT-mod3_pred

#lets check the correlation between the actual an predicted output
#before everything convert it to antilog then check the correlation 
mod3_pred_antilog=np.exp(mod3_pred)
mod3_pred_antilog.corr(wcat.AT)#0.763380458365053

plt.scatter(wcat.Waist,wcat.AT,color="red")
plt.plot(wcat.Waist,mod3_pred_antilog);plt.xlabel("Waist");plt.ylabel("AT")

""" here it came less then we should go to quadratic model before that we are getting less values 
when we took np.log(AT), so lets take the same value for quadratic modela and will check"""


wcat["Waist_sq"]=wcat.Waist*wcat.Waist
wcat.columns

quad_mod=smf.ols("np.log(AT)~wcat.Waist+wcat.Waist_sq", data=wcat).fit()
quad_mod.summary()
print(quad_mod.conf_int(0.01)) # 99% confidence level
"""
R-squared:                       0.779----> increased in R2 will see
Adj. R-squared:                  0.775
 
 =================================================================================
                    coef    std err          t      P>|t|      [0.025      0.975]
---------------------------------------------------------------------------------
Intercept        -7.8241      1.473     -5.312      0.000     -10.744      -4.904
wcat.Waist        0.2289      0.032      7.107      0.000       0.165       0.293
wcat.Waist_sq    -0.0010      0.000     -5.871      0.000      -0.001      -0.001
==============================================================================
"""

quad_mod_pred=quad_mod.predict(wcat)

#before checking correlation convert it to antilog method

quad_mod_pred_anti_log=np.exp(quad_mod_pred)
residual_error_quad_mod=wcat.AT-quad_mod_pred_anti_log

#lets check the correlation between the final output prediction an actual output variable

quad_mod_pred_anti_log.corr(wcat.AT)#0.8285111314182692


plt.scatter(wcat.Waist,wcat.AT,color="red")
plt.plot(wcat.Waist,quad_mod_pred_anti_log);plt.xlabel("Waist");plt.ylabel("AT")

""" I WANT TO SEE THE SCATTER DIAGRAM FOR RESIDUAL ERROR TO CHECK THE HOMOSCADASTICITY"""

import statsmodels.api as sm
fig = sm.qqplot(residual_errors)
 #plt.show()


# CROSS VALIDATION
from sklearn.model_selection import train_test_split
train,test=train_test_split(wcat,test_size=0.3)
train_model=smf.ols("np.log(AT)~wcat.Waist+wcat.Waist_sq", data=train).fit()
train_model.summary()
"""
R-squared:                       0.779
Adj. R-squared:                  0.775

=================================================================================
                    coef    std err          t      P>|t|      [0.025      0.975]
---------------------------------------------------------------------------------
Intercept        -7.8241      1.473     -5.312      0.000     -10.744      -4.904
wcat.Waist        0.2289      0.032      7.107      0.000       0.165       0.293
wcat.Waist_sq    -0.0010      0.000     -5.871      0.000      -0.001      -0.001
==============================================================================
"""
train_pred=train_model.predict(train)
"""
train_pred=train_model.predict(train)
Traceback (most recent call last):

  File "<ipython-input-197-0bf2e96395f0>", line 1, in <module>
    train_pred=train_model.predict(train)

  File "C:\ProgramData\Anaconda3\lib\site-packages\statsmodels\base\model.py", line 837, in predict
    exog = dmatrix(design_info, exog, return_type="dataframe")

  File "C:\ProgramData\Anaconda3\lib\site-packages\patsy\highlevel.py", line 291, in dmatrix
    NA_action, return_type)

  File "C:\ProgramData\Anaconda3\lib\site-packages\patsy\highlevel.py", line 169, in _do_highlevel_design
    return_type=return_type)

  File "C:\ProgramData\Anaconda3\lib\site-packages\patsy\build.py", line 893, in build_design_matrices
    rows_checker.check(value.shape[0], name, origin)

  File "C:\ProgramData\Anaconda3\lib\site-packages\patsy\build.py", line 795, in check
    raise PatsyError(msg, origin)

PatsyError: Number of rows mismatch between data argument and wcat.Waist (76 versus 109)
    np.log(AT)~wcat.Waist+wcat.Waist_sq
               ^^^^^^^^^^




"""

train.columns
train.shape
wcat.shape
test.shape
"""
# TOMORROW TOPICS
RE ADJUSTED R2
CREATING DUMMY VARIABLES
HANDLING CATEGARICAL VAUES
"""




















































