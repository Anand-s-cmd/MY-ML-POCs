"""PRACTICE OF MLR"""
# Multilinear Regression
import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt
import statsmodels.formula.api as smf

# loading the data
cars = pd.read_csv("C:\\EXCELR\\NOTES WRITTEN\\Regression\\multilinear regression\\cars.csv")
type(cars)

cars.corr()
import seaborn as sns
sns.pairplot(cars)
cars.columns
#WE HAVE COLINEARITY PROBLEM BETWEEN VARAIBLE INPUTS SO LETS BULLD THE MODEL FIRST 

mod1=smf.ols("MPG~HP+VOL+SP+WT",data=cars).fit()
mod1.params
"""
Intercept    30.677336
HP           -0.205444
VOL          -0.336051
SP            0.395627
WT            0.400574
dtype: float64
"""
mod1.summary()
"""
MPG   R-squared:        0.771
OLS   Adj. R-squared    0.758
==============================================================================
                 coef    std err          t      P>|t|      [0.025      0.975]
------------------------------------------------------------------------------
Intercept     30.6773     14.900      2.059      0.043       1.001      60.354
HP            -0.2054      0.039     -5.239      0.000      -0.284      -0.127
VOL           -0.3361      0.569     -0.591      0.556      -1.469       0.796
SP             0.3956      0.158      2.500      0.015       0.080       0.711
WT             0.4006      1.693      0.237      0.814      -2.972       3.773
==============================================================================
"""

#SO INDIDUALLY WILL BUILD THE MODEL FOR VOL AD WT SEPERTE FIRST
mod1_vol=smf.ols("MPG~VOL",data=cars).fit()
mod1_vol.summary()# HERE P VAL IS LOW SO IT IS SIGNIFICANT
mod1_wt=smf.ols("MPG~WT",data=cars).fit()
mod1_wt.summary()# HERE P VAL IS LOW SO IT IS SIGNIFICANT

#LETS COMBINE BOTH AND CHECK
mod1_wT_vol=smf.ols("MPG~WT+VOL",data=cars).fit()    
mod1_wT_vol.summary()
"""
WHEN WE ARE TAKING THEM BOTH THE P VAL FOR BOTH IS HIGH SO THEY ARE BECOMING INSIGNIFICANT
==============================================================================
                 coef    std err          t      P>|t|      [0.025      0.975]
------------------------------------------------------------------------------
Intercept     56.8847      4.534     12.546      0.000      47.858      65.912
WT             1.4349      2.929      0.490      0.626      -4.397       7.266
VOL           -0.6983      0.984     -0.710      0.480      -2.658       1.261
=======================================================================
"""

#NOW WE HAVE TO DROP ANY ONE OF THE VARIABLE SO FOR THAT 
# WE SHOULD USE VIF AND avplot METHODS TO UNDERSTAND WHICH IS CONTIBUTING MORE TOWARDS 
# COLINEARITY AND WHICH IS LESSLY CONTRIBUTING TOWARDS PREDICTION


rsq_hp = smf.ols('HP~WT+VOL+SP',data=cars).fit().rsquared  
vif_hp = 1/(1-rsq_hp) 

rsq_wt = smf.ols('WT~HP+VOL+SP',data=cars).fit().rsquared  
vif_wt = 1/(1-rsq_wt) 

rsq_vol = smf.ols('VOL~WT+SP+HP',data=cars).fit().rsquared  
vif_vol = 1/(1-rsq_vol) 

rsq_sp = smf.ols('SP~WT+VOL+HP',data=cars).fit().rsquared  
vif_sp = 1/(1-rsq_sp) 

d1={'variables':['HP','WT','VOL','SP'],'VIF':[vif_hp,vif_wt,vif_vol,vif_sp]}
vif_frame=pd.DataFrame(d1)

#WHEN VIF VALUES S GREATER THAN 10 ITS CONTRIBUTING MORE TOWARDS COLINEARITY

"""-----------BEFORE BUILDING FINAL MODEL LETS LOOK AT VARIBLE AND OUTLIES WITH ALL ROWS FOR ALL COLUMNS"""
""" BECAUSE AS PER ASSUMPTIONS OUR OBSERVATIONS SHOULD BE EQUALLY RELIABLE OR NOT """
"""NOW IMPORT STATSMODEL TO USE AVPLOTS AS WELL AS INFLUENCEINDEX FOR FINDING OUTLIERS"""
import statsmodels.api as sm
""" HERE AVPLOTS IS LIKE sm.graphics.plot_partregress_grid(ml_new)"""
# Added varible plot 
sm.graphics.plot_partregress_grid(mod1)

#TO REMIVE OUTLIERS AS WELL FOR ALL ROWS
sm.graphics.influence_plot(mod1)

cars_new=cars.drop(cars.index[76],axis=0)#cars_new=cars.drop(cars.index[76,70],axis=0)
#OMLT WILL REMOVE 76 AND WILL SEE 
"""HERE ABOVE IF I DONT WANT TO SAVE NEW DF BUT WANT TO SAVE IN OLD SET ONLT THEN WE SHOULD USE
inplace=True THEN IT REMOVES THE COLUMN AND SAVES THE DATA IN THE OLD DF ONLY"""

"""LETS BUILD THE NEW MODELWITH REMOVING ONLY OUTLIES
 THAT INFLUENCE OBSERVATION BUT KEEP THE WT IN THE INPUT LIST"""
 
mod2=smf.ols("MPG~HP+VOL+SP+WT",data=cars_new).fit()
mod2.summary()

"""
MPG   R-squared:                       0.819
OLS   Adj. R-squared:                  0.810
==============================================================================
                 coef    std err          t      P>|t|      [0.025      0.975]
------------------------------------------------------------------------------
Intercept     27.8268     13.323      2.089      0.040       1.287      54.367
HP            -0.2266      0.035     -6.413      0.000      -0.297      -0.156
VOL           -0.1855      0.509     -0.364      0.717      -1.199       0.828
SP             0.4119      0.141      2.913      0.005       0.130       0.694
WT             0.0375      1.515      0.025      0.980      -2.980       3.055
======
"""

"""HERE STILL ADJ R2 AND R2 VALUE OS MORE IT DID NOT SOLVE THE COLINEARITY PROBLEM 
SO WILL DROP WT NOW AND BUILD THE FINAL MODEL"""

final_mod=smf.ols("MPG~HP+VOL+SP",data=cars_new).fit()
final_mod.summary()

"""
MPG   R-squared:                       0.819
OLS   Adj. R-squared:                  0.812
==============================================================================
                 coef    std err          t      P>|t|      [0.025      0.975]
------------------------------------------------------------------------------
Intercept     27.7555     12.922      2.148      0.035       2.018      53.493
HP            -0.2268      0.035     -6.525      0.000      -0.296      -0.158
VOL           -0.1729      0.021     -8.178      0.000      -0.215      -0.131
SP             0.4124      0.139      2.963      0.004       0.135       0.690
==============================================================================

"""

"""-------------AS WE CAN SEE ADJ R2 VALUE HAS INCREASED FROM 0.810 TO 0.812"""



"""SO USE FINAL MOD TO PREDICT NOW"""
MPG_PRED=final_mod.predict(cars_new)
resid_errors=cars_new.MPG-MPG_PRED
zero_mean_error=np.sum(resid_errors)#---> 4.021671884402167e-12
MPG_PRED.corr(cars_new.MPG)# 0.9051034363548393
rmse = np.sqrt(np.mean(resid_errors*resid_errors)) # 3.8808025682640657
#TO CHECK AV PLOSTS FOR FINAL MOD HERE IT IS
sm.graphics.plot_partregress_grid(final_mod)


######  Linearity #########
"""WHEN IT COMES TO FIRST LINEARITY THEN WE HAVE TO CHECK
Y AND X1,X2,X3-------- BEFORE BUILDING THE MODEL WE ARE CHECKING WITH SCATTER DIAGRAM
BUT AFTER BUILDING THE MODEL WE SHOULD CHECK FOR THE B0, B1,B2-------
HERE cars_new.MPG IS Y AND  MPG_PRED IS Y^ THAT IS B0, B1...."""
# Observed values VS Fitted values
plt.scatter(cars_new.MPG,MPG_PRED,c="r");plt.xlabel("observed_values");plt.ylabel("fitted_values")
"""HERE WE ARE CHECKING LINEARITY BTW Y=B0+B1 THAT IS Y=Y^
AFTER BUILDING THE MODEL THAT PREDICTED VALUES THAT IS AGAIN MPG_PRED"""

# Residuals VS Fitted Values """ CHECKING HOMOHETERSCEDASTICITY
"""
HERE CHECKING WITH THE BLUE LINE THAT IS
WHETHER ERRORS ARE DISTRUBUTED IDENTICALLY ON BOTH SIDES OR NOT
"""
#CHECKING HOMOHETERSCEDASTICITY
plt.scatter(MPG_PRED,final_mod.resid_pearson,c="r");plt.axhline(y=0,color='blue');plt.xlabel("fitted_values");plt.ylabel("residuals")
#ABOBE CHECKING HOMESCEDASTICITY

########    Normality plot for residuals ######
# histogram
plt.hist(final_mod.resid_pearson) # Checking the standardized residuals are normally distributed

# QQ plot for residuals 
import pylab          
import scipy.stats as st

# Checking Residuals are normally distributed
st.probplot(final_mod.resid_pearson, dist="norm", plot=pylab)


### Splitting the data into train and test data 

from sklearn.model_selection import train_test_split
cars_train,cars_test  = train_test_split(cars_new,test_size = 0.2) # 20% size

#TAKING cars_train DATA SET BECAUSE IT HAS NO OUTLIERS
# preparing the model on train data 

model_train = smf.ols("MPG~HP+SP+VOL",data=cars_train).fit()

# train_data prediction
train_pred = model_train.predict(cars_train)

# train residual values 
train_resid  = train_pred - cars_train.MPG

# RMSE value for train data 
train_rmse = np.sqrt(np.mean(train_resid*train_resid)) # 4.04 

# prediction on test data set 
test_pred = model_train.predict(cars_test)

# test residual values 
test_resid  = test_pred - cars_test.MPG

# RMSE value for test data 
test_rmse = np.sqrt(np.mean(test_resid*test_resid)) # 3.16

#original rmse is 3.88888
