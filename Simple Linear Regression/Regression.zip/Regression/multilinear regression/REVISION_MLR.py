"""NEW MULTINLINEAR REGRESSION TASK SAME PROBLEM"""
# Multilinear Regression
import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt
import statsmodels.formula.api as smf

# loading the data
cars = pd.read_csv("C:\\EXCELR\\NOTES WRITTEN\\Regression\\multilinear regression\\cars.csv")

type(cars)
cars.corr()
import seaborn as sns
sns.pairplot(cars)
cars.columns
#['HP', 'MPG', 'VOL', 'SP', 'WT

#FIRST BUILD THE MODEL
mod1=smf.ols("MPG~HP+VOL+SP+WT",data=cars).fit()
mod1.summary()

# so we have to remove one variable to check that we check VIF values which is high that can be removed as well
#as AVplots which is lessly contributing towards prediction we get to know


rsq_hp = smf.ols('HP~WT+VOL+SP',data=cars).fit().rsquared  
vif_hp = 1/(1-rsq_hp) 

rsq_wt =  smf.ols('WT~HP+VOL+SP',data=cars).fit().rsquared  
vif_wt = 1/(1-rsq_wt) 

rsq_vol =  smf.ols('VOL~HP+WT+SP',data=cars).fit().rsquared  
vif_vol = 1/(1-rsq_vol) 

rsq_sp =  smf.ols('SP~HP+WT+VOL',data=cars).fit().rsquared  
vif_sp = 1/(1-rsq_sp) 

d1={'variables':['HP','WT','VOL','SP'],'VIF':[vif_hp,vif_wt,vif_vol,vif_sp]}
vif_frame=pd.DataFrame(d1)
"""
  variables         VIF
0        HP   19.926589
1        WT  639.533818
2       VOL  638.806084
3        SP   20.007639
"""

#first AV plot

import statsmodels.api as sm
""" HERE AVPLOTS IS LIKE sm.graphics.plot_partregress_grid(ml_new)"""
# Added varible plot 
sm.graphics.plot_partregress_grid(mod1)

#and also check for the outliers as well
#TO REMIVE OUTLIERS AS WELL FOR ALL ROWS
""" BECAUSE AS PER ASSUMPTIONS OUR OBSERVATIONS SHOULD BE EQUALLY RELIABLE OR NOT """
sm.graphics.influence_plot(mod1)

cars_new=cars.drop(cars.index[76],axis=0)

mod2=smf.ols("MPG~WT+SP+VOL+HP",data=cars_new).fit()
mod2.summary()
# it did not solve colinearity problem so remove wt and build the model

mod3=smf.ols("MPG~SP+VOL+HP",data=cars_new).fit()
mod3.summary()

mod3_pred=mod3.predict(cars_new)
residual_errors=cars_new.MPG-mod3_pred
np.sum(residual_errors)#-2.8066438062523957e-13
#take RMSE now
np.sqrt(np.mean(residual_errors*residual_errors))#3.8808025682640657

mod3_pred.corr(cars_new.MPG)# 0.905103436354839


sm.graphics.plot_partregress_grid(mod3)
plt.scatter(cars_new.MPG,mod3_pred,c="r");plt.xlabel("observed_values");plt.ylabel("fitted_values")












