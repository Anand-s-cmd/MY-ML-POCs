import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

claimants = pd.read_csv("C:\\EXCELR\\NOTES WRITTEN\\SOLVING_ASSIGNMENTS\\Logistic Regression\\claimants.csv")
corrmat = claimants.corr()
top_corr_features = corrmat.index
plt.figure(figsize=(10,10))
#plot heat map
g=sns.heatmap(claimants[top_corr_features].corr(),annot=True,cmap="RdYlGn")
sns.heatmap(claimants.isnull(),yticklabels=False,cbar=False,cmap='viridis')
claimants.columns
"""
['CASENUM', 'ATTORNEY', 'CLMSEX', 'CLMINSUR', 'SEATBELT', 'CLMAGE',
       'LOSS']
"""
claimants.shape
claimants.head()

import statsmodels.formula.api as smf
import seaborn as sns
sns.heatmap(claimants.isnull(),yticklabels=False,cbar=False,cmap='viridis')

claimants.isnull().sum()



sns.boxplot(x="CLMSEX",y="CLMAGE",data=claimants)
"""ABOVE FROM BOX PLOT WE CHECKED ANU OUTLIERS ARE THERE ARE NOT BUT IT WAS NOT THERE 
INCASE OUTLIERS WERE PRESENT THEN?????????????????????????????????????????????????"""
plt.boxplot(claimants.LOSS)
claimants.describe()

claimants.CLMAGE = claimants.CLMAGE.fillna(claimants.CLMAGE.mean())

claimants.CLMINSUR.value_counts()
"""FOR CLMINSUR MODE WE NEED WE CAN EITHER DO LIKE DIS OR 
1.0    1179
0.0     120
Name: CLMINSUR, dtype: int64
"""
claimants.CLMINSUR = claimants.CLMINSUR.fillna(1)
""" OR
claimants['CLMINSUR']=claimants['CLMINSUR'].fillna(claimants['CLMINSUR'].mode()[0])
"""

claimants.CLMSEX.value_counts()
claimants.CLMSEX = claimants.CLMSEX.fillna(1)

claimants.SEATBELT.value_counts()
claimants.SEATBELT = claimants.SEATBELT.fillna(0)

sns.heatmap(claimants.isnull(),yticklabels=False,cbar=False,cmap='viridis')
claimants.isnull().sum()
claimants.corr()
#Model building 
import statsmodels.formula.api as smf
logit_model = smf.logit('ATTORNEY~CLMAGE+LOSS+CLMINSUR+CLMSEX+SEATBELT',data = claimants).fit()
logit_model.summary()

"""
==============================================================================
Dep. Variable:               ATTORNEY   No. Observations:                 1340
Model:                          Logit   Df Residuals:                     1334
Method:                           MLE   Df Model:                            5
Date:                Sat, 26 Oct 2019   Pseudo R-squ.:                  0.1209
Time:                        03:17:19   Log-Likelihood:                -816.24
converged:                       True   LL-Null:                       -928.48
                                        LLR p-value:                 1.620e-46
==============================================================================
                 coef    std err          z      P>|z|      [0.025      0.975]
------------------------------------------------------------------------------
Intercept     -0.1493      0.226     -0.660      0.509      -0.592       0.294
CLMAGE         0.0066      0.003      2.058      0.040       0.000       0.013
LOSS          -0.3228      0.029    -10.962      0.000      -0.381      -0.265
CLMINSUR       0.5284      0.210      2.516      0.012       0.117       0.940
CLMSEX         0.3204      0.120      2.674      0.008       0.086       0.555
SEATBELT      -0.6718      0.522     -1.286      0.198      -1.696       0.352
==============================================================================
"""
"""HERE LOOK AT LLR p-value, IT SAYS OUR MODE IS SIGNIFICANT SINCE IT IS LESS THAN 0.5"""

"""
HERE AGAIN NULL DEVIANCE ND RESIDUAL DEVIANVCE ARE GIVEN LIKE
Log-Likelihood:                -816.24
LL-Null:                       -928.48
ALWAYS RES DEV < NULL DEV
"""
""" HERE NOW SEATBELT(0.198) IS NOT SIGNIFICANT SO WILL REMOVE AND BULD A MODEL"""


logit_model2 = smf.logit('ATTORNEY~CLMAGE+LOSS+CLMINSUR+CLMSEX',data = claimants).fit()
logit_model2.summary()

"""
NOW ALL ARE SIGNIFICANT VALUES LETS BUILD THE QUATION
Y=-0.1589+0.0067(CLMAGE)-0.3232(LOSS)+0.5233(CLMINSUR)+0.3232(CLMSEX)

HERE 
WHATEVER THE COEFFICIENTS WE HAVE GOT THOSE ARE FOR CLASS 1 THAT IS FEMALE CLIENT
CLMSEX(1)
"""


"""
CLMSEX         0.3204
HERE WE CAN SAY ODDS() FEMALE CLIENT NOT HIRING AN ATTORNEY IS E(0.3232) 
THAN MALE CLIENT NOT HIRING AN ATTORNEY"""

"""
"""

y_pred = logit_model2.predict(claimants)
claimants["pred_prob"] = y_pred

claimants.head(2)
"""
   CASENUM  ATTORNEY  CLMSEX    ...      CLMAGE    LOSS  pred_prob
0        5         0     0.0    ...        50.0  34.940   0.000025
1        3         1     1.0    ...        18.0   0.891   0.499302
HERE IF WE OBSERVE ATTORNEY FIRST ROW IS 0 AND pred_prob IS ELSO 0
BUT IN 2nd ROW ATTORNEY IS 1 BUT pred_prob IS 0 LESS THAN 0.5 MEANS IT IS MISS MATCH
"""

# Creating new column for storing predicted class of Attorney

# filling all the cells with zeroes
claimants["Att_val"] = 0
"""OR claimants["Att_val"] = np.zeros(1340)"""
# taking threshold value as 0.5 and above the prob value will be treated 
# as correct value 
claimants.loc[y_pred>=0.5,"Att_val"] = 1
claimants.head(10)

from sklearn.metrics import classification_report
C_R=classification_report(claimants.Att_val,claimants.ATTORNEY)
print(C_R)
"""
THIS IS FOR 0.5 CUT OFF VALUE
                 precision    recall  f1-score   support
0.0               0.63         0.75      0.68       581
1.0               0.77         0.67      0.72       759

avg / total       0.71         0.70      0.70      1340


"""
confusion_matrix = pd.crosstab(claimants.Att_val,claimants['ATTORNEY'])
"""
                ATTORNEY    0    1
                Att_val          
 PREDICTE D                0         433  148
                           1         252  507
                           
                                    TN  FN
                                    FP  TP                           
"""
accuracy = (433+507)/(1340) #  0.7014925373134329--> TN+TP/TOTAL
"""ACCURACY=SUM(DIAG)/TOT"""
accuracy# 0.7014925373134329
error=(252+148)/(1340)
error#0.29850746268656714

# ROC curve 
from sklearn import metrics
# fpr => false positive rate
# tpr => true positive rate
fpr, tpr, threshold = metrics.roc_curve(claimants.ATTORNEY, y_pred)

plt.plot(fpr,tpr);plt.xlabel("False Positive");plt.ylabel("True Positive")
 
roc_auc = metrics.auc(fpr, tpr) # area under ROC curve 
roc_auc#0.7590405081629242


#AUC---> Area Under the Curve
#---->#0.7590405081629242 is good curve
#ALWAYS AREA UNDR THE CURVE SHOULD BE MORE

""" Dividing data into train and test data sets"""
claimants.columns
"""'CASENUM', 'ATTORNEY', 'CLMSEX', 'CLMINSUR', 'SEATBELT', 'CLMAGE',
       'LOSS', 'pred_prob', 'Att_val'"""
claimants.drop("Att_val",axis=1,inplace=True)
claimants.drop("pred_prob",axis=1,inplace=True)
from sklearn.model_selection import train_test_split

train,test = train_test_split(claimants,test_size=0.3)

# checking na values 
train.isnull().sum()
test.isnull().sum()

# Building a model on train data set 

train_model = smf.logit('ATTORNEY~CLMAGE+LOSS+CLMINSUR+CLMSEX+SEATBELT',data = train).fit()
train.columns

#summary
train_model.summary()
train.head(4)
train_pred = train_model.predict(train.iloc[:,1:])
train.head(4)
# Creating new column for storing predicted class of Attorney

# filling all the cells with zeroes
train["train_pred"] = np.zeros(938)
train.head(4)
# taking threshold value as 0.5 and above the prob value will be treated 
# as correct value 
train.loc[train_pred>0.5,"train_pred"] = 1

# confusion matrix 
train_confusion_matrix = pd.crosstab(train.train_pred,train['ATTORNEY'])

train_confusion_matrix
"""
                ATTORNEY               0    1
                Att_val          
 PREDICTE D                0         433  148
                           1         252  507
                           
                                    TN  FN
                                    FP  TP  
                                    
                                    ATTORNEY       0    1
train_pred          
                            0.0                   309  105
                            1.0                   170  354
                            
                                    ATTORNEY       0    1
train_pred          
                                0.0               290  102
                                1.0               187  359
"""
accuracy_train = (309+354)/(938) #  0.7068230277185501  359+290
"""NEW DATA CME AS--------->
accuracy_train = (290+359)/(938)
0.69189
"""
accuracy_train# 0.7068230277185501
train.shape#(938, 9)

# Prediction on Test data set

test_pred = train_model.predict(test)

# Creating new column for storing predicted class of Attorney

# filling all the cells with zeroes
test.shape
test.head(4)
test["test_pred"] = np.zeros(402)
test.shape
test.head(4)
# taking threshold value as 0.5 and above the prob value will be treated 
# as correct value 
test.loc[test_pred>0.5,"test_pred"] = 1

# confusion matrix 
test_confusion_matrix = pd.crosstab(test.test_pred,test['ATTORNEY'])

confusion_matrix
"""
MY NEW DATA CAME AS 

                                             0    1  ATTORNEY
                        Att_val           
                                  0         433  148
                                  1         252  507
accuracy_test=433+507
"""
accuracy_test = (126+161)/(402) # 71.39
accuracy_test













