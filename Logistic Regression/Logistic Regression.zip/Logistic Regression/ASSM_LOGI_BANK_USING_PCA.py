""" LOGISTIC REGRESSION ASSIGNMENT BANK_DATA USIG PCA"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

bank = pd.read_csv("C:\\EXCELR\\NOTES WRITTEN\\SOLVING_ASSIGNMENTS\\Logistic Regression\\solution\\bank_data.csv")
bank_copied=bank.copy()
bank.head(5)
bank.shape
bank.isnull().sum()

bank=bank.iloc[:,0:31]
bank.head(5)

bank_normal=scale(bank)

pca=PCA(n_components=31)
pca_values=pca.fit_transform(bank_normal)
# The amount of variance that each PCA explains is 
var=pca.explained_variance_ratio_

# Cumulative variance 

var1 = np.cumsum(np.round(var,decimals = 4)*100)
var1
"""
array([11.01, 18.4 , 24.56, 29.54, 33.93, 37.93, 41.73, 45.46, 49.11,
       52.71, 56.23, 59.66, 63.05, 66.41, 69.72, 73.02, 76.27, 79.44,
       82.51, 85.44, 88.31, 91.12, 93.86, 96.12, 98.11, 99.5 , 99.99,
       99.99, 99.99, 99.99, 99.99])

SO FOR 21ST VALUES ACCURACY IS 88.31 THAT IS ENOUGH
"""

# creating a csv file 
#Univ.to_csv("University_cluster.csv",encoding="utf-8")

#airline.to_csv("C:\\EXCELR\\NOTES WRITTEN\\SOLVING_ASSIGNMENTS\\Clustering\\CLUSTERED_K_MEAN_Univsersity.csv")

################## Clustering  ##########################
new_df_bank = pd.DataFrame(pca_values[:,0:21])
new_df_bank.head()
new_df_bank.shape
new_df_bank["Y"]=bank_copied.y
new_df_bank.columns
bank_copied.head()


new_df_bank.columns = ['PC1', 'PC2', 'PC3', 'PC4', 'PC5', 'PC6', 'PC7', 'PC8', 'PC9', 'PC10', 'PC11', 'PC12', 'PC13', 'PC14', 'PC15', 'PC16', 'PC17', 'PC18', 'PC19', 'PC20', 'PC21', 'Y']
new_df_bank.columns
new_df_bank.to_csv("C:\\EXCELR\\NOTES WRITTEN\\SOLVING_ASSIGNMENTS\\Logistic Regression\\solution\\new_df_bank_PCA.csv")

#Model building 

bank2 = pd.read_csv("C:\\EXCELR\\NOTES WRITTEN\\SOLVING_ASSIGNMENTS\\Logistic Regression\\solution\\new_df_bank_PCA.csv")

import statsmodels.formula.api as sm
logit_model1 = sm.logit('Y~PC1+PC2+PC3+PC4+PC5+PC6+PC7+PC8+PC9+PC10+PC11+PC12+PC13+PC14+PC15+PC16+PC17+PC18+PC19+PC20+PC21',data = bank2).fit()


#summary
logit_model1.summary()
logit_model2 = sm.logit('Y~PC1+PC2+PC3+PC4+PC5+PC7+PC8+PC9+PC10+PC11+PC12+PC13+PC14+PC15+PC16+PC17+PC18+PC19+PC21',data = bank2).fit()
logit_model2.summary()
logit_model3 = sm.logit('Y~PC1+PC2+PC3+PC4+PC5+PC7+PC8+PC9+PC10+PC11+PC12+PC13+PC15+PC16+PC17+PC18+PC19+PC21',data = bank2).fit()
logit_model3.summary()
y_pred = logit_model3.predict(bank2)

bank2["pred_prob"] = y_pred

# filling all the cells with zeroes
bank2["Y_VAL"] = 0

# taking threshold value as 0.5 and above the prob value will be treated 
# as correct value 
bank2.loc[y_pred>=0.5,"Y_VAL"] = 1
bank2.Y_VAL

confusion_matrix = pd.crosstab(bank2.Y,bank2['Y_VAL'])

confusion_matrix
accuracy = (39017+1675)/(45211) # 0.9000464488730618
accuracy#0.9000464488730618

# ROC curve 
from sklearn import metrics
# fpr => false positive rate
# tpr => true positive rate
fpr, tpr, threshold = metrics.roc_curve(bank2.Y, y_pred)


# the above function is applicable for binary classification class 

plt.plot(fpr,tpr);plt.xlabel("False Positive");plt.ylabel("True Positive")
 
roc_auc = metrics.auc(fpr, tpr) # area under ROC curve 

roc_auc#0.8861935813596202
