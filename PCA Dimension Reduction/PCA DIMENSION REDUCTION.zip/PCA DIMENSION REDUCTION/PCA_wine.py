import pandas as pd 
import numpy as np
wine = pd.read_csv("C:\\EXCELR\\NOTES WRITTEN\\SOLVING_ASSIGNMENTS\\PCA DIMENSION REDUCTION\\wine.csv")
wine.describe()
wine.head()

from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
from sklearn.preprocessing import scale

wine=wine.iloc[:,1:]

wine_normal=scale(wine)

pca=PCA(n_components=13)
pca_values=pca.fit_transform(wine_normal)

pca_values[0]
# The amount of variance that each PCA explains is 
var=pca.explained_variance_ratio_

# Cumulative variance 

var1 = np.cumsum(np.round(var,decimals = 4)*100)
var1

################## Clustering  ##########################
new_df = pd.DataFrame(pca_values[:,0:4])
new_df.head()


from sklearn.cluster import KMeans

kmeans = KMeans(n_clusters = 3)
kmeans.fit(new_df)
kmeans.labels_
