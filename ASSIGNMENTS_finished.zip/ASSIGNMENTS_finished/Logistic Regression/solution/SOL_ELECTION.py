""" ELECTION"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns


"""
SINCE IN THE CSV FILE AS FIRST ROW IS NAN WE ARE DROPPING HE FIRST ROW NOW

"""

election = pd.read_csv("C:\\EXCELR\\NOTES WRITTEN\\SOLVING_ASSIGNMENTS\\Logistic Regression\\solution\\election_data.csv", skiprows=[1],dtype={"Result":"int64","Year":"int64","Popularity Rank":"int64"})
election.head(10)

election.columns

election=election.rename(columns={"Election-id": "Electionid", "Amount Spent": "AmountSpent", "Popularity Rank": "PopularityRank"})
election.shape

corrmat = election.corr()
top_corr_features = corrmat.index
plt.figure(figsize=(10,10))
#plot heat map
g=sns.heatmap(election[top_corr_features].corr(),annot=True,cmap="RdYlGn")
sns.heatmap(election.isnull(),yticklabels=False,cbar=False,cmap='viridis')

election.head(10)

import statsmodels.formula.api as smf
import seaborn as sns
sns.heatmap(election.isnull(),yticklabels=False,cbar=False,cmap='viridis')
sns.heatmap(election.isnull(),yticklabels=False,cbar=False,cmap='viridis')
election.isnull().sum()
"""
Electionid        0
Result            0
Year              0
AmountSpent       0
PopularityRank    0
"""

election.corr()
election.columns
#Model building 
import statsmodels.formula.api as smf
#import statsmodels.formula.api as smf
#logit_model = smf.logit('ATTORNEY~CLMAGE+LOSS+CLMINSUR+CLMSEX+SEATBELT',data = claimants).fit()
#""" DONT CO SIDER ELECTION_D SINCE IT IS UNIQUE"""
"""We hav removed ELECTIONID and YEAR"""
logit_model = smf.logit('Result~AmountSpent+PopularityRank',data = election).fit()
"""
impppppppppppppppppppppppppppppppp

https://en.wikipedia.org/wiki/Invertible_matrix
The determinant of that matrix is (calculations are explained later):

[3  8
 4  6]

3×6 − 8×4 = 18 − 32 = −14

when it is non zero it is invertible matrix
when its 0 its not invertible
"""
logit_model.summary()

election.head(10)
"""
                           Logit Regression Results                           
==============================================================================
Dep. Variable:                 Result   No. Observations:                   10
Model:                          Logit   Df Residuals:                        7
Method:                           MLE   Df Model:                            2
Date:                Sat, 09 Nov 2019   Pseudo R-squ.:                  0.7164
Time:                        20:46:47   Log-Likelihood:                -1.9088
converged:                      False   LL-Null:                       -6.7301
                                        LLR p-value:                  0.008056
==================================================================================
                     coef    std err          z      P>|z|      [0.025      0.975]
----------------------------------------------------------------------------------
Intercept         61.8530   2.79e+04      0.002      0.998   -5.46e+04    5.47e+04
AmountSpent       -0.1068      2.832     -0.038      0.970      -5.657       5.443
PopularityRank   -20.2513   9290.144     -0.002      0.998   -1.82e+04    1.82e+04
==================================================================================
"""


y_pred = logit_model.predict(election)
election["pred_prob"] = y_pred
election["PRED_RESULT"] = 0

election.loc[y_pred>=0.5,"PRED_RESULT"] = 1
election.head(10)

from sklearn.metrics import classification_report
C_R=classification_report(election.PRED_RESULT,election.Result)
print(C_R)
"""
             precision    recall  f1-score   support

          0       0.75      1.00      0.86         3
          1       1.00      0.86      0.92         7

avg / total       0.93      0.90      0.90        10
"""

confusion_matrix = pd.crosstab(election.PRED_RESULT,election.Result)

"""
Result       0  1
PRED_RESULT      
0            3  0
1            1  6
          
             TN  FN
             FP  TP
"""

accuracy = (3+6)/(10)
accuracy# 0.9

error=(1+0)/(10)
error#0.1



# ROC curve 
from sklearn import metrics
# fpr => false positive rate
# tpr => true positive rate
fpr, tpr, threshold = metrics.roc_curve(election.Result, y_pred)

plt.plot(fpr,tpr);plt.xlabel("False Positive");plt.ylabel("True Positive")
 
roc_auc = metrics.auc(fpr, tpr) # area under ROC curve 
roc_auc# 0.9583333333333334


#AUC---> Area Under the Curve
#---->#0.7590405081629242 is good curve
#ALWAYS AREA UNDR THE CURVE SHOULD BE MORE

""" Dividing data into train and test data sets"""
election.columns
"""'CASENUM', 'ATTORNEY', 'CLMSEX', 'CLMINSUR', 'SEATBELT', 'CLMAGE',
       'LOSS', 'pred_prob', 'Att_val'"""
election.drop("PRED_RESULT",axis=1,inplace=True)
election.drop("pred_prob",axis=1,inplace=True)
from sklearn.model_selection import train_test_split

train,test = train_test_split(election,test_size=0.3)

# checking na values 
train.isnull().sum()
test.isnull().sum()

# Building a model on train data set 
 
train_model = smf.logit('Result~Year+AmountSpent+PopularityRank',data = train).fit()
"""

  File "C:\ProgramData\Anaconda3\lib\site-packages\statsmodels\discrete\discrete_model.py", line 203, in _check_perfect_pred
    raise PerfectSeparationError(msg)

PerfectSeparationError: Perfect separation detected, results not available
"""
train.columns

#summary
train_model.summary()
train.head(4)
train_pred = train_model.predict(train.iloc[:,1:])
train.head(4)
# Creating new column for storing predicted class of Attorney

# filling all the cells with zeroes
train["train_pred"] = np.zeros(938)
train.head(4)
# taking threshold value as 0.5 and above the prob value will be treated 
# as correct value 
train.loc[train_pred>0.5,"train_pred"] = 1

# confusion matrix 
train_confusion_matrix = pd.crosstab(train.train_pred,train['ATTORNEY'])

train_confusion_matrix
"""
                ATTORNEY               0    1
                Att_val          
 PREDICTE D                0         433  148
                           1         252  507
                           
                                    TN  FN
                                    FP  TP  
                                    
                                    ATTORNEY       0    1
train_pred          
                            0.0                   309  105
                            1.0                   170  354
                            
                                    ATTORNEY       0    1
train_pred          
                                0.0               290  102
                                1.0               187  359
"""
accuracy_train = (309+354)/(938) #  0.7068230277185501  359+290
"""NEW DATA CME AS--------->
accuracy_train = (290+359)/(938)
0.69189
"""
accuracy_train# 0.7068230277185501
train.shape#(938, 9)

# Prediction on Test data set

test_pred = train_model.predict(test)

# Creating new column for storing predicted class of Attorney

# filling all the cells with zeroes
test.shape
test.head(4)
test["test_pred"] = np.zeros(402)
test.shape
test.head(4)
# taking threshold value as 0.5 and above the prob value will be treated 
# as correct value 
test.loc[test_pred>0.5,"test_pred"] = 1

# confusion matrix 
test_confusion_matrix = pd.crosstab(test.test_pred,test['ATTORNEY'])

confusion_matrix
"""
MY NEW DATA CAME AS 

                                             0    1  ATTORNEY
                        Att_val           
                                  0         433  148
                                  1         252  507
accuracy_test=433+507
"""
accuracy_test = (126+161)/(402) # 71.39
accuracy_test

