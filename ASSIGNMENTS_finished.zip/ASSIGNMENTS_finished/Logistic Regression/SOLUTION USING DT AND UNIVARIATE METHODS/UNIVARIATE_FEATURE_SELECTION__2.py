""" UNIVARIATE FEATURE SELECTION """

import pandas as pd
import numpy as np
from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import chi2

data=pd.read_csv(r"C:\\EXCELR\NOTES WRITTEN\\SOLVING_ASSIGNMENTS\\Logistic Regression\\bank_data.csv")
data=data.abs()

data.shape
x= data.iloc[:,0:31]  #independent columns
y = data.iloc[:,-1]    #target column i.e price range

#apply SelectKBest class to extract top 10 best features
bestfeatures=SelectKBest(score_func=chi2, k=10)
fit=bestfeatures.fit(x,y)

dfscores=pd.DataFrame(fit.scores_)
dfcolumns=pd.DataFrame(x.columns)


#concat two dataframes for better visualization 
featurescores=pd.concat([dfcolumns,dfscores],axis=1)

featurescores.columns = ['Specs','Score']  #naming the dataframe columns
print(featurescores.nlargest(10,'Score')) 
featurescores.head(10)
"""
           Specs         Score
5       duration  1.807711e+06
2        balance  7.223507e+05
7          pdays  1.134616e+05
11   poutsuccess  4.113001e+03
8       previous  3.593220e+03
6       campaign  8.405821e+02
15   con_unknown  7.333549e+02
3        housing  3.889497e+02
13  con_cellular  2.940171e+02
24     joretired  2.696993e+02

CONSIDER THESE ONLY COLUMNS THEN

"""
#new_data=pd.DataFrame(featurescores.nlargest(10,'Score'))
new_data=data[['duration','balance','pdays','poutsuccess','previous','campaign','con_unknown','housing','con_cellular','joretired']]

new_data.isnull().sum()
"""
duration        0
balance         0
pdays           0
poutsuccess     0
previous        0
campaign        0
con_unknown     0
housing         0
con_cellular    0
joretired       0
"""

new_data.columns
"""
we need o add y output variable to the new data set
"""

data.shape
new_data['y']=y
new_data.shape
new_data.columns

from sklearn.model_selection import train_test_split 
train,test=train_test_split(new_data,test_size=0.3) 

import statsmodels.formula.api as smf
logit_model = smf.logit('y~duration+balance+pdays+poutsuccess+previous+campaign+con_unknown+housing+con_cellular+joretired',data = train).fit()
logit_model.summary()
"""
con_cellular     pvalue-0.106 removing that var
"""
logit_model = smf.logit('y~duration+balance+pdays+poutsuccess+previous+campaign+con_unknown+housing+joretired',data = train).fit()
logit_model.summary()

y_pred=logit_model.predict(train)
train['predictions']=y_pred
train.shape#(31647, 13)
train['Predictions_new']=np.zeros(31647)
train.tail(10)
train.loc[y_pred>=0.5,"Predictions_new"] = 1

conf_matrix=pd.crosstab(train.Predictions_new,train.y)
"""
y                    0     1
Predictions_new             
0.0              27310  2521
1.0                655  1161
"""
accuracy_val=(27310+1161)/31647# 0.8996429361392865
error_val=1-accuracy_val# 0.10035706386071352

from sklearn import metrics

fpr,tpr,threshold=metrics.roc_curve(train.y,y_pred)
fpr
tpr
threshold
plt.plot(fpr,tpr);plt.xlabel("False Positive");plt.ylabel("True Positive")

roc_auc = metrics.auc(fpr, tpr) # area under ROC curve 
roc_auc# 0.8883090458090849

""" for testing data """

test_pred=logit_model.predict(test)
test.shape
test.columns
test['predictions']=test_pred
test['new_predictions']=np.zeros(13564)
test.loc[test_pred>0.5,'new_predictions']=1
test.tail()

test_conf_matrix=pd.crosstab(test.y,test.new_predictions)
"""
new_predictions    0.0  1.0
y                          
0                11694  263
1                 1086  521
"""
test_accuracy=(11694+521)/13564# 0.9005455617811855
test_error=1-test_accuracy#0.0994544382188145

from sklearn import metrics
fpr,tpr,threshold=metrics.roc_curve(test.y,test_pred)
plt.plot(fpr,tpr);plt.xlabel("False Positive");plt.ylabel("True Positive")
test_roc_auc= metrics.auc(fpr, tpr) #0.8756015579368907

