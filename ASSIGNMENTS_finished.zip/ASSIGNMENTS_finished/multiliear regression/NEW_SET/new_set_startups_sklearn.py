""" new_set_startups """
import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt
import statsmodels.formula.api as smf
from sklearn.preprocessing import OneHotEncoder
# loading the data
df = pd.read_csv("C:\\EXCELR\\NOTES WRITTEN\\SOLVING_ASSIGNMENTS\\multiliear regression\\startups.csv")
df=df.rename(columns={"R&D Spend": "RD_spend", "Marketing Spend": "Marketing_Spend"})
df.columns

df.head()
""" HERE WE HAVE STATE A CATEGORICAL VARIABLE WITH 3 TYPES SO WE HAVE GO FOR ONE HOT ENCODING FOR THIS TO CONVERT"""

df1=pd.get_dummies(df['State'],drop_first=True)
df=pd.concat([df1,df],axis=1)
df.drop('State',axis=1,inplace=True)
df.columns
X=df.iloc[:,:-1]
y=df.iloc[:,[5]]

from sklearn.model_selection import train_test_split
X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.25)

from sklearn.linear_model import LinearRegression
regression=LinearRegression()
regression.fit(X_train,y_train)

y_pred=regression.predict(X_test)

from sklearn.metrics import r2_score
score=r2_score(y_test,y_pred)

score
"""score
Out[943]: 0.9718558745749257
"""
